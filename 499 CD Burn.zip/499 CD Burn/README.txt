North South University

Course: Senior Design Project - II (CSE499B)
Section: 04
Semester: Spring, 2019
Faculty: Mirza Mohammad Lutfe Elahi (MLE)

Project: NSU Canteen Automation
Group: Going Out Of Business

Members:
1. Mohammed Adib Khan - 1430420042 (adib.khan@northsouth.edu)
2. Rifat Arefin Badhon - 1511738042 (rifat.arefin@northsouth.edu)
3. Sarwat Islam Dipanzan - 1510117042 (dipanzan.islam@northsouth.edu)