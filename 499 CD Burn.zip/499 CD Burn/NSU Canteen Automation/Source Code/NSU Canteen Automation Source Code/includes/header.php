<header id="header" class="page-topbar">
        <!-- start header nav-->
        <div class="navbar-fixed">
            <nav class="navbar-color">
                <div class="nav-wrapper">
                    <ul class="left">   

                      <li><h1 class="logo-wrapper"> <a href="#" class="brand-logo darken-1">NSU Canteen</a> <span class="logo-text"></span></h1></li>
                      <!--
                      <li><h1 class="logo-wrapper"><a href="#" class="brand-logo darken-1"><img src="images/materialize-logo.png" alt="logo"></a> <span class="logo-text">Logo</span></h1></li>
                    -->
                    </ul>
                    <ul class="right">   
                      <li><a href="#" class="waves-effect waves-block waves-light"><b style="font-size: 24px">৳ <?php echo $balance;?></b></a>
                      </li>
                      <!--                     
                      <li><a href="#" class="waves-effect waves-block waves-light"><i class="mdi-editor-attach-money"><?php echo $balance;?></i></a>
                      </li>
                      -->
                    </ul>               
                </div>
            </nav>
        </div>
        <!-- end header nav-->
  </header>
