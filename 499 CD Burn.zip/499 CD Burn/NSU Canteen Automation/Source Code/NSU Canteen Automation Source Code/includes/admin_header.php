<header id="header" class="page-topbar">
        <!-- start header nav-->
        <div class="navbar-fixed">
            <nav class="navbar-color">
                <div class="nav-wrapper">
                    <ul class="left">   
                      <li><h1 class="logo-wrapper"><a href="#" class="brand-logo darken-1">NSU Canteen</a> <span class="logo-text">Logo</span></h1></li>
                      <!--
                      <li><h1 class="logo-wrapper"><a href="#" class="brand-logo darken-1"><img src="images/materialize-logo.png" alt="logo"></a> <span class="logo-text">Logo</span></h1></li>
                    -->
                    </ul>               
                </div>
            </nav>
        </div>
        <!-- end header nav-->
  </header>

