<!-- START FOOTER -->
  <footer class="page-footer">
    <div class="footer-copyright">
      <div class="container" align="center">
        <span>Team: Going Out Of Business</span>
      </div>
    </div>
  </footer>
<!-- END FOOTER -->