<?php
include('../functions/functions.php');

appStart();

getMenu();


?>